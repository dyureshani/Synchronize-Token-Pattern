How to run the project

Download the project

Extract the project

Copy the project folder to your WAMP server's www folder

Start WAMP server

1) for Synchronize Token Pattern - Open your web browser and navigate the URL http://localhost/CSRF-Synchronozer_Token_Pattern/

2) for double submit cookie Pattern - Open your web browser and navigate the URL http://localhost/CSRF-Double_Submit_Cookie_Pattern/

Username = yoshi and Password = 1234

To see more Details go to below blog Posts

 http://yureshani.blogspot.com/2018/10/synchronize-token-pattern.html
 http://yureshani.blogspot.com/2018/10/double-submit-cookie-pattern.html